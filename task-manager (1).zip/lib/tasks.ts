"use server"

import type { Task } from "@/types/task"

// In-memory storage for tasks (in a real app, this would be a database)
let tasks: Task[] = [
  {
    id: "1",
    title: "Complete project proposal",
    completed: false,
    createdAt: new Date(Date.now() - 86400000).toISOString(), // 1 day ago
    priority: "high",
  },
  {
    id: "2",
    title: "Review pull requests",
    completed: true,
    createdAt: new Date(Date.now() - 172800000).toISOString(), // 2 days ago
    completedAt: new Date(Date.now() - 43200000).toISOString(), // 12 hours ago
    priority: "medium",
  },
  {
    id: "3",
    title: "Plan team meeting",
    completed: false,
    createdAt: new Date(Date.now() - 259200000).toISOString(), // 3 days ago
    priority: "low",
  },
]

export async function getTasks(): Promise<Task[]> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500))
  return [...tasks].sort((a, b) => {
    // Sort by completion status (incomplete first)
    if (a.completed !== b.completed) {
      return a.completed ? 1 : -1
    }
    // Then by priority (high first)
    const priorityOrder = { high: 0, medium: 1, low: 2 }
    const aPriority = priorityOrder[a.priority || "medium"]
    const bPriority = priorityOrder[b.priority || "medium"]
    if (aPriority !== bPriority) {
      return aPriority - bPriority
    }
    // Then by creation date (newest first)
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  })
}

export async function getTask(id: string): Promise<Task | null> {
  await new Promise((resolve) => setTimeout(resolve, 300))
  return tasks.find((task) => task.id === id) || null
}

export async function createTask(taskData: Partial<Task>): Promise<Task> {
  await new Promise((resolve) => setTimeout(resolve, 500))

  const newTask: Task = {
    id: Date.now().toString(),
    title: taskData.title || "",
    completed: false,
    createdAt: new Date().toISOString(),
    priority: taskData.priority || "medium",
  }

  tasks = [newTask, ...tasks]
  return newTask
}

export async function updateTask(id: string, taskData: Partial<Task>): Promise<Task> {
  await new Promise((resolve) => setTimeout(resolve, 500))

  const taskIndex = tasks.findIndex((task) => task.id === id)
  if (taskIndex === -1) {
    throw new Error(`Task with ID ${id} not found`)
  }

  const updatedTask = {
    ...tasks[taskIndex],
    ...taskData,
  }

  tasks[taskIndex] = updatedTask
  return updatedTask
}

export async function deleteTask(id: string): Promise<void> {
  await new Promise((resolve) => setTimeout(resolve, 500))

  const taskIndex = tasks.findIndex((task) => task.id === id)
  if (taskIndex === -1) {
    throw new Error(`Task with ID ${id} not found`)
  }

  tasks.splice(taskIndex, 1)
}
