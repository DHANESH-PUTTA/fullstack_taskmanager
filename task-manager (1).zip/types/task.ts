export interface Task {
  id: string
  title: string
  completed: boolean
  createdAt: string
  completedAt?: string | null
  priority?: "low" | "medium" | "high"
  description?: string
}
