"use client"

import { useState, useEffect } from "react"
import { getTasks } from "@/lib/tasks"
import type { Task } from "@/types/task"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

export function TaskStats() {
  const [tasks, setTasks] = useState<Task[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const loadTasks = async () => {
      try {
        const fetchedTasks = await getTasks()
        setTasks(fetchedTasks)
      } catch (error) {
        console.error("Failed to fetch tasks:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadTasks()
  }, [])

  const totalTasks = tasks.length
  const completedTasks = tasks.filter((task) => task.completed).length
  const pendingTasks = totalTasks - completedTasks
  const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0

  const highPriorityTasks = tasks.filter((task) => task.priority === "high").length
  const mediumPriorityTasks = tasks.filter((task) => task.priority === "medium").length
  const lowPriorityTasks = tasks.filter((task) => task.priority === "low").length

  if (isLoading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="flex justify-center">
            <div className="h-6 w-6 animate-spin rounded-full border-b-2 border-gray-800" />
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Task Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm font-medium">Completion Rate</span>
                <span className="text-sm font-medium">{completionRate}%</span>
              </div>
              <Progress value={completionRate} />
            </div>

            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="space-y-1">
                <span className="text-3xl font-bold">{totalTasks}</span>
                <p className="text-xs text-muted-foreground">Total Tasks</p>
              </div>
              <div className="space-y-1">
                <span className="text-3xl font-bold text-green-500">{completedTasks}</span>
                <p className="text-xs text-muted-foreground">Completed</p>
              </div>
              <div className="space-y-1">
                <span className="text-3xl font-bold text-orange-500">{pendingTasks}</span>
                <p className="text-xs text-muted-foreground">Pending</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Priority Breakdown</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm font-medium text-red-500">High Priority</span>
                <span className="text-sm font-medium">{highPriorityTasks}</span>
              </div>
              <Progress
                value={totalTasks > 0 ? (highPriorityTasks / totalTasks) * 100 : 0}
                className="bg-red-100"
                indicatorClassName="bg-red-500"
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm font-medium text-blue-500">Medium Priority</span>
                <span className="text-sm font-medium">{mediumPriorityTasks}</span>
              </div>
              <Progress
                value={totalTasks > 0 ? (mediumPriorityTasks / totalTasks) * 100 : 0}
                className="bg-blue-100"
                indicatorClassName="bg-blue-500"
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm font-medium text-green-500">Low Priority</span>
                <span className="text-sm font-medium">{lowPriorityTasks}</span>
              </div>
              <Progress
                value={totalTasks > 0 ? (lowPriorityTasks / totalTasks) * 100 : 0}
                className="bg-green-100"
                indicatorClassName="bg-green-500"
              />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
