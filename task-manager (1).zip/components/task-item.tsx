"use client"

import { useState } from "react"
import type { Task } from "@/types/task"
import { updateTask, deleteTask } from "@/lib/tasks"
import { Checkbox } from "@/components/ui/checkbox"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Pencil, Trash2, X, Check } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { formatDistanceToNow } from "@/lib/utils"

interface TaskItemProps {
  task: Task
  onUpdate: (task: Task) => void
  onDelete: (id: string) => void
}

export function TaskItem({ task, onUpdate, onDelete }: TaskItemProps) {
  const [isEditing, setIsEditing] = useState(false)
  const [editedTitle, setEditedTitle] = useState(task.title)
  const [isDeleting, setIsDeleting] = useState(false)
  const [isUpdating, setIsUpdating] = useState(false)

  const handleToggleComplete = async () => {
    try {
      setIsUpdating(true)
      const updatedTask = await updateTask(task.id, {
        ...task,
        completed: !task.completed,
        completedAt: !task.completed ? new Date().toISOString() : null,
      })
      onUpdate(updatedTask)
    } catch (error) {
      console.error("Failed to update task:", error)
    } finally {
      setIsUpdating(false)
    }
  }

  const handleSaveEdit = async () => {
    if (editedTitle.trim() === "") return

    try {
      setIsUpdating(true)
      const updatedTask = await updateTask(task.id, {
        ...task,
        title: editedTitle.trim(),
      })
      onUpdate(updatedTask)
      setIsEditing(false)
    } catch (error) {
      console.error("Failed to update task:", error)
    } finally {
      setIsUpdating(false)
    }
  }

  const handleDelete = async () => {
    try {
      setIsDeleting(true)
      await deleteTask(task.id)
      onDelete(task.id)
    } catch (error) {
      console.error("Failed to delete task:", error)
      setIsDeleting(false)
    }
  }

  return (
    <Card className={`border-l-4 ${task.completed ? "border-l-green-500" : "border-l-orange-500"}`}>
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className="mt-1">
            <Checkbox checked={task.completed} onCheckedChange={handleToggleComplete} disabled={isUpdating} />
          </div>

          <div className="flex-1">
            {isEditing ? (
              <div className="flex gap-2">
                <Input
                  value={editedTitle}
                  onChange={(e) => setEditedTitle(e.target.value)}
                  className="flex-1"
                  autoFocus
                />
                <Button size="sm" onClick={handleSaveEdit} disabled={isUpdating}>
                  <Check className="h-4 w-4" />
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    setIsEditing(false)
                    setEditedTitle(task.title)
                  }}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <p className={`text-base ${task.completed ? "line-through text-muted-foreground" : ""}`}>
                    {task.title}
                  </p>
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setIsEditing(true)}
                      disabled={isDeleting || isUpdating}
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={handleDelete}
                      disabled={isDeleting || isUpdating}
                      className="text-red-500 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <div className="flex gap-2 text-xs text-muted-foreground">
                  <span>Created {formatDistanceToNow(task.createdAt)} ago</span>
                  {task.priority && (
                    <Badge
                      variant={
                        task.priority === "high" ? "destructive" : task.priority === "medium" ? "default" : "secondary"
                      }
                    >
                      {task.priority}
                    </Badge>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
