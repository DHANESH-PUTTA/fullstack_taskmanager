import { TaskStats } from "@/components/task-stats"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function Dashboard() {
  return (
    <main className="container mx-auto py-10 px-4 max-w-4xl">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <Link href="/">
          <Button variant="outline">Back to Tasks</Button>
        </Link>
      </div>

      <div className="grid gap-8">
        <TaskStats />
      </div>
    </main>
  )
}
