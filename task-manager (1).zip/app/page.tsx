import { TaskList } from "@/components/task-list"
import { CreateTaskForm } from "@/components/create-task-form"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function Home() {
  return (
    <main className="container mx-auto py-10 px-4 max-w-4xl">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Task Manager</h1>
        <Link href="/dashboard">
          <Button>Dashboard</Button>
        </Link>
      </div>

      <div className="grid gap-8">
        <CreateTaskForm />
        <TaskList />
      </div>
    </main>
  )
}
